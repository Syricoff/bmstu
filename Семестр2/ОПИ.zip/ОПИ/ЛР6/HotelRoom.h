#ifndef HOTELROOM_H
#define HOTELROOM_H

#include <string>
#include <ostream>
#include "RoomType.h"

class HotelRoom {
public:
    HotelRoom(int id, const RoomType& roomType, const std::string& checkInDate, const std::string& checkOutDate, unsigned int guests, double cost, const std::string& note);
    HotelRoom(int id, const std::string& roomType, unsigned int maxGuests, double pricePerNight, const std::string& checkInDate, const std::string& checkOutDate, unsigned int guests, double cost, const std::string& note);
    HotelRoom(const std::string& roomType, unsigned int maxGuests, double pricePerNight, const std::string& checkInDate, const std::string& checkOutDate, unsigned int guests, double cost, const std::string& note);
    HotelRoom();
    HotelRoom(const RoomType& roomType, const std::string& checkInDate, const std::string& checkOutDate, unsigned int guests, double cost, const std::string& note);

    int getId() const;
    std::string getRoomType() const;
    double getPricePerNight() const;
    std::string getCheckInDate() const;
    std::string getCheckOutDate() const;
    unsigned int getNumGuests() const;
    double getTotalCost() const;
    std::string getNotes() const;

    void setId(int uniqueId);
    void setRoomType(const std::string& roomType);
    void setPricePerNight(double pricePerNight);
    void setCheckInDate(const std::string& checkInDate);
    void setCheckOutDate(const std::string& checkOutDate);
    void setNumGuests(unsigned int numGuests);
    void setTotalCost(double totalCost);
    void setNotes(const std::string& notes);

    static void setMinNextId(int id);

    friend std::ostream& operator<<(std::ostream& os, const HotelRoom& room);

private:
    int m_uniqueId;
    RoomType m_roomType;
    std::string m_checkInDate;
    std::string m_checkOutDate;
    unsigned int m_numGuests;
    double m_totalCost;
    std::string m_notes;

    static int nextId;
};

#endif // HOTELROOM_H
