#include "RoomType.h"

RoomType::RoomType(const std::string& type, unsigned int maxGuests, double pricePerNight)
    : m_type(type), m_maxGuests(maxGuests), m_pricePerNight(pricePerNight) {}

std::string RoomType::getType() const {
    return m_type;
}

unsigned int RoomType::getMaxGuests() const {
    return m_maxGuests;
}

double RoomType::getPricePerNight() const {
    return m_pricePerNight;
}

void RoomType::setType(const std::string& type) {
    m_type = type;
}

void RoomType::setMaxGuests(unsigned int maxGuests) {
    m_maxGuests = maxGuests;
}

void RoomType::setPricePerNight(double pricePerNight) {
    m_pricePerNight = pricePerNight;
}
