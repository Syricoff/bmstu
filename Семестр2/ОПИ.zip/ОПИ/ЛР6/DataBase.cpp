#include "DataBase.h"

const std::map<std::string, RoomType> DataBase::m_roomTypes = {
    {"Стандартный", RoomType("Стандартный", 2, 2000.0)},
    {"Полулюкс", RoomType("Полулюкс", 3, 5000.0)},
    {"Люкс", RoomType("Люкс", 4, 7000.0)},
    {"Семейный", RoomType("Семейный", 6, 5500.0)},
    {"Апартаменты", RoomType("Апартаменты", 8, 10000.0)}
};

DataBase::DataBase(const std::string& filePath) : m_filePath(filePath) {
    loadRecords();
}

DataBase::~DataBase() {
    saveRecords();
    m_records.clear();
}

void DataBase::loadRecords() {
    std::ifstream file(m_filePath);
    if (file.is_open()) {
        std::string line;
        std::getline(file, line); // Skip the header row

        m_records.clear();

        while (std::getline(file, line)) {
            std::vector<std::string> fields = splitLine(line, ';');
            if (fields.size() >= 8) {
                int id = std::stoi(fields[0]);
                std::string roomType = fields[1];
                std::string checkInDate = fields[3];
                std::string checkOutDate = fields[4];
                unsigned int numGuests = std::stoi(fields[5]);
                double totalCost = std::stod(fields[6]);
                std::string notes = fields[7];

                if (fields.size() > 8) {
                    for (size_t i = 8; i < fields.size(); i++) {
                        notes += ";" + fields[i];
                    }
                }

                HotelRoom room(id, m_roomTypes.at(roomType), checkInDate, checkOutDate, numGuests, totalCost, notes);
                m_records.emplace_back(std::move(room));
            }
        }

        file.close();
    } else {
        std::cerr << "Error opening file: " << m_filePath << std::endl;
    }
    HotelRoom::setMinNextId(m_records.empty() ? 0 : std::max_element(m_records.begin(), m_records.end(), [](const HotelRoom& a, const HotelRoom& b) { return a.getId() < b.getId(); })->getId());
}

void DataBase::saveRecords() {
    std::ofstream file(m_filePath);
    if (file.is_open()) {
        file << "id;тип номера;цена за ночь;дата заезда;дата выезда;количество гостей;общая стоимость;примечания" << std::endl;

        for (const HotelRoom& room : m_records) {
            file << room << std::endl;
        }
        file.close();
    } else {
        std::cerr << "Error opening file: " << m_filePath << std::endl;
    }
}

List DataBase::getRecords() const {
    return m_records;
}

HotelRoom* DataBase::getRecord(int id) {
    auto it = std::find_if(m_records.begin(), m_records.end(), [id](const HotelRoom& room) { return room.getId() == id; });
    return it != m_records.end() ? &*it : new HotelRoom();
}

void DataBase::addRecord(const HotelRoom& room) {
    m_records.emplace_back(room);
    saveRecords();
}

void DataBase::deleteRecord(int id) {
    auto it = std::find_if(m_records.begin(), m_records.end(), [id](const HotelRoom& room) { return room.getId() == id; });
    if (it != m_records.end()) {
        m_records.erase(it);
        saveRecords();
    }
}

void DataBase::editRecord(int id, const HotelRoom& newRoom) {
    auto it = std::find_if(m_records.begin(), m_records.end(), [id](const HotelRoom& room) { return room.getId() == id; });
    if (it != m_records.end()) {
        *it = newRoom;
        saveRecords();
    }
}

std::vector<std::string> DataBase::splitLine(const std::string& line, char delimiter) {
    std::vector<std::string> fields;
    std::stringstream ss(line);
    std::string field;
    while (std::getline(ss, field, delimiter)) {
        fields.emplace_back(std::move(field));
    }
    return fields;
}
