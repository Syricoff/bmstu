#include "pch.h"
#include "CppUnitTest.h"
#include "DataBase.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace DataBaseTests
{
    TEST_CLASS(DataBaseTests)
    {
    public:
        TEST_METHOD(LoadRecords)
        {
            std::string testFilePath = "test_database.csv";
            DataBase database(testFilePath);
            Assert::AreEqual(database.getRecords().size(), size_t(0));
            database.addRecord(HotelRoom(1, database.m_roomTypes.at("Стандартный"), "2023-06-01", "2023-06-03", 2, 4000.0, ""));
            database.addRecord(HotelRoom(2, database.m_roomTypes.at("Люкс"), "2023-07-01", "2023-07-05", 4, 28000.0, ""));
            Assert::AreEqual(database.getRecords().size(), size_t(2));
        }

        TEST_METHOD(GetRecord)
        {
            std::string testFilePath = "test_database.csv";
            DataBase database(testFilePath);
            database.addRecord(HotelRoom(1, database.m_roomTypes.at("Стандартный"), "2023-06-01", "2023-06-03", 2, 4000.0, ""));
            HotelRoom* room = database.getRecord(1);
            Assert::IsNotNull(room);
            Assert::AreEqual(room->getId(), 1);
            Assert::AreEqual(room->getRoomType().getName(), "Стандартный");
            Assert::AreEqual(room->getCheckInDate(), "2023-06-01");
            Assert::AreEqual(room->getCheckOutDate(), "2023-06-03");
            Assert::AreEqual(room->getNumGuests(), 2);
            Assert::AreEqual(room->getTotalCost(), 4000.0);
            Assert::AreEqual(room->getNotes(), "");
        }

        TEST_METHOD(AddRecord)
        {
            std::string testFilePath = "test_database.csv";
            DataBase database(testFilePath);
            database.addRecord(HotelRoom(1, database.m_roomTypes.at("Стандартный"), "2023-06-01", "2023-06-03", 2, 4000.0, ""));
            Assert::AreEqual(database.getRecords().size(), size_t(1));
        }

        TEST_METHOD(DeleteRecord)
        {
            std::string testFilePath = "test_database.csv";
            DataBase database(testFilePath);
            database.addRecord(HotelRoom(1, database.m_roomTypes.at("Стандартный"), "2023-06-01", "2023-06-03", 2, 4000.0, ""));
            database.deleteRecord(1);
            Assert::AreEqual(database.getRecords().size(), size_t(0));
        }

        TEST_METHOD(EditRecord)
        {
            std::string testFilePath = "test_database.csv";
            DataBase database(testFilePath);
            database.addRecord(HotelRoom(1, database.m_roomTypes.at("Стандартный"), "2023-06-01", "2023-06-03", 2, 4000.0, ""));
            HotelRoom newRoom(1, database.m_roomTypes.at("Люкс"), "2023-07-01", "2023-07-05", 4, 28000.0, "");
            database.editRecord(1, newRoom);
            HotelRoom* room = database.getRecord(1);
            Assert::IsNotNull(room);
            Assert::AreEqual(room->getId(), 1);
            Assert::AreEqual(room->getRoomType().getName(), "Люкс");
            Assert::AreEqual(room->getCheckInDate(), "2023-07-01");
            Assert::AreEqual(room->getCheckOutDate(), "2023-07-05");
            Assert::AreEqual(room->getNumGuests(), 4);
            Assert::AreEqual(room->getTotalCost(), 28000.0);
            Assert::AreEqual(room->getNotes(), "");
        }

        TEST_CLEANUP()
        {
            std::remove("test_database.csv");
        }
    };
}
