#ifndef DATABASE_H
#define DATABASE_H

#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include "HotelRoom.h"

using List = std::vector<HotelRoom>;

class DataBase {
public:
    DataBase(const std::string& filePath);

    ~DataBase();

    List getRecords() const;
    HotelRoom* getRecord(int id);
    void addRecord(const HotelRoom& room);
    void deleteRecord(int id);
    void editRecord(int id, const HotelRoom& newRoom);

    const std::map<std::string, RoomType>& getRoomTypes() const {
        return m_roomTypes;
    }

private:
    void loadRecords();
    void saveRecords();
    static std::vector<std::string> splitLine(const std::string& line, char delimiter);

private:
    std::string m_filePath;
    List m_records;
    static const std::map<std::string, RoomType> m_roomTypes;
};

#endif // DATABASE_H
