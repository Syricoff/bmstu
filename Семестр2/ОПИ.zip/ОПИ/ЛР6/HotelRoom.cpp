#include "HotelRoom.h"

int HotelRoom::nextId = 1;

void HotelRoom::setMinNextId(int id) {
    HotelRoom::nextId = id + 1;
}

HotelRoom::HotelRoom(int id, const RoomType& roomType, const std::string& checkInDate, const std::string& checkOutDate, unsigned int guests, double cost, const std::string& note)
    : m_uniqueId(id), m_roomType(roomType), m_checkInDate(checkInDate), m_checkOutDate(checkOutDate), m_numGuests(guests), m_totalCost(cost), m_notes(note) {}

HotelRoom::HotelRoom(int id, const std::string& roomType, unsigned int maxGuests, double pricePerNight, const std::string& checkInDate, const std::string& checkOutDate, unsigned int guests, double cost, const std::string& note)
    : m_uniqueId(id), m_roomType(roomType, maxGuests, pricePerNight), m_checkInDate(checkInDate), m_checkOutDate(checkOutDate), m_numGuests(guests), m_totalCost(cost), m_notes(note) {}

HotelRoom::HotelRoom(const std::string& roomType, unsigned int maxGuests, double pricePerNight, const std::string& checkInDate, const std::string& checkOutDate, unsigned int guests, double cost, const std::string& note)
    : m_uniqueId(nextId++), m_roomType(roomType, maxGuests, pricePerNight), m_checkInDate(checkInDate), m_checkOutDate(checkOutDate), m_numGuests(guests), m_totalCost(cost), m_notes(note) {}

HotelRoom::HotelRoom()
    : m_uniqueId(nextId++), m_roomType("", 0, 0.0), m_checkInDate(""), m_checkOutDate(""), m_numGuests(0), m_totalCost(0.0), m_notes("") {}

HotelRoom::HotelRoom(const RoomType& roomType, const std::string& checkInDate, const std::string& checkOutDate, unsigned int guests, double cost, const std::string& note)
    : m_uniqueId(nextId++), m_roomType(roomType), m_checkInDate(checkInDate), m_checkOutDate(checkOutDate), m_numGuests(guests), m_totalCost(cost), m_notes(note) {}

int HotelRoom::getId() const {
    return m_uniqueId;
}

std::string HotelRoom::getRoomType() const {
    return m_roomType.getType();
}

double HotelRoom::getPricePerNight() const {
    return m_roomType.getPricePerNight();
}

std::string HotelRoom::getCheckInDate() const {
    return m_checkInDate;
}

std::string HotelRoom::getCheckOutDate() const {
    return m_checkOutDate;
}

unsigned int HotelRoom::getNumGuests() const {
    return m_numGuests;
}

double HotelRoom::getTotalCost() const {
    return m_totalCost;
}

std::string HotelRoom::getNotes() const {
    return m_notes;
}

void HotelRoom::setId(int uniqueId) {
    m_uniqueId = uniqueId;
}

void HotelRoom::setRoomType(const std::string& roomType) {
    m_roomType.setType(roomType);
}

void HotelRoom::setPricePerNight(double pricePerNight) {
    m_roomType.setPricePerNight(pricePerNight);
}

void HotelRoom::setCheckInDate(const std::string& checkInDate) {
    m_checkInDate = checkInDate;
}

void HotelRoom::setCheckOutDate(const std::string& checkOutDate) {
    m_checkOutDate = checkOutDate;
}

void HotelRoom::setNumGuests(unsigned int numGuests) {
    m_numGuests = numGuests;
}

void HotelRoom::setTotalCost(double totalCost) {
    m_totalCost = totalCost;
}

void HotelRoom::setNotes(const std::string& notes) {
    m_notes = notes;
}

std::ostream& operator<<(std::ostream& os, const HotelRoom& room) {
    os << room.m_uniqueId << ";"
       << room.getRoomType() << ";"
       << room.getPricePerNight() << ";"
       << room.m_checkInDate << ";"
       << room.m_checkOutDate << ";"
       << room.m_numGuests << ";"
       << room.m_totalCost << ";"
       << room.m_notes << ";";
    return os;
}
