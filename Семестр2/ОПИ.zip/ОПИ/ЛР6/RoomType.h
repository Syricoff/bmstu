#ifndef ROOMTYPE_H
#define ROOMTYPE_H

#include <string>

class RoomType {
public:
    RoomType(const std::string& type, unsigned int maxGuests, double pricePerNight);

    std::string getType() const;
    unsigned int getMaxGuests() const;
    double getPricePerNight() const;

    void setType(const std::string& type);
    void setMaxGuests(unsigned int maxGuests);
    void setPricePerNight(double pricePerNight);

private:
    std::string m_type;
    unsigned int m_maxGuests;
    double m_pricePerNight;
};

#endif // ROOMTYPE_H
